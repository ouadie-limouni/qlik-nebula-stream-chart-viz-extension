define(['./dist/streamchart'], (supernova) => supernova);
